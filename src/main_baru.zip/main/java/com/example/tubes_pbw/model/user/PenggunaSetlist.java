package com.example.tubes_pbw.model.user;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PenggunaSetlist {
    String email;
    int idSetlist;
}
